<?php require_once "controllData.php";?>
<!DOCTYPE html>
<html>
    <head>
        <title> Reset Page </title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <section>
            <div class="leftBox">
                <div class="title">
                    <h1> Reset Password </h1>
                </div>
                <div class="content">
                    <form action="#" method="POST">
                    <label for="userId">Username </label>
                        <input type="text" name="userId" placeholder="Enter your Username">
                        <br>
                        <label for="userEmail">Enter Email:</label>
                        <input type="text" name="userEmail" placeholder="Email"><br/><br/>
                        <input type="submit" name="cancel" value="Cancel" class="btn-form">
                        <input type="submit" name="check" value="Next" class="btn-form">
                    </form>
                </div>
            </div>
                <div class="mainImg">
                    <img src="Tea.jpg" width="775px" height="600px">
                </div>
        </section>
    </body>
</html>