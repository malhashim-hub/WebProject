<?php require_once "controllData.php";?>
<!DOCTYPE html>
<html>
    <head>
        <title> Create Account Page </title>
        <style>
            html {
                background: url("Background.png") no-repeat center center fixed; 
                background-size: cover;
            }
            .box {
                border: 5px rgb(138, 24, 24);
                background-color: white;
                text-align: center;
                max-width: 30%;
                display: flex;
                justify-content: center;
                align-items: top;
                text-align: center;
                min-height: 73vh;
                top: 50%;
                left: 50%;
                margin-top: 6%;
                margin-left: 33%;
                border-radius: 10%;
            }
            .box .content .title {
                font-size: 80%;
                font-family:Verdana, Geneva, Tahoma, sans-serif;
                color: #6E8EC4;
            }
            .box .content .img {
                margin: 10%;
            }
            .submit-btn{
            text-align: center;
            width: 70%;
            padding: 8.5px 0;
            cursor: pointer;
            margin: 5px 0;
            background: #6E8EC4;
            border: 0;
            outline: none;
            border-radius: 30px;
            color: #fff;
            font-size: 20px;
            margin-top:15px;
            }
            button{
                background: none;
	            color: inherit;
	            border: none;
	            padding: 0;
	            font: inherit;
	            cursor: pointer;
	            outline: inherit;
            }
        </style>
    </head>
    <body>
        <div class="background"></div>
        <div class="box">
            <div class="content">
                <div class="img">
                    <img src="welcome.png" width="65%">
                </div>
                <div class="title">
                    <h1> Change Password Was Successfully! </h1>
                    <br>
                </div>
                <div class="loginNow">
                    <form action="#" method="POST">
                        <input type="submit" class="submit-btn" name="cancel" value="Login Now">
                    </form>
                
                </div>
            </div>
        </div>
    </body>
</html>