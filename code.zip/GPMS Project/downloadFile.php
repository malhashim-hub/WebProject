<?php
$dbh = new PDO("mysql:host=localhost;dbname=GPMSDB","root","");
$id = isset($_GET['id_project'])? $_GET['id_project'] :"";
//$sql = "SELECT * FROM  projectinfo WHERE id_project = ?";
    //$result=mysqli_query($conn,$sql);
    $stat = $dbh->prepare("SELECT * FROM  projectinfo WHERE id_project = ?");
    $stat->bindParam(1,$id);
    $stat->execute();
    $row = $stat->fetch();
    
    header('Content-Type:'.$row['mime']);
    
    echo $row['data'];  
    
    
?>