<?php
 require "config.php";

    session_start();
    $userId="";
    $uname ="";
    $userEmail="";
    $id_lead = "";
    $errors = array();
    $uname="";
    $dbh = new PDO("mysql:host=localhost;dbname=GPMSDB","root","");
    if(isset($_POST['login'])){
    
        $userId=$_POST["userId"];
        $pass=$_POST["password"];
        $check_id="select * from users where KFU_id= '".$userId."'";
        $result=mysqli_query($conn,$check_id);
        if(mysqli_num_rows($result) > 0){
           $row=mysqli_fetch_array($result);
           $fetch_pass = $row['password'];
           
           if(password_verify($pass,$fetch_pass)){
                $uname = $row['Fname'];
                $_SESSION["Fname"] = $uname;

            if($row["user_type"]=="admin"){
            
            header("location:adminP1.php");
        }else if($row["user_type"]=="supervisor"){
            $_SESSION['idsupervisor'] = $userId;
            header("location:superP1.php");
        }else if($row["user_type"]=="student"){
                
                if($row["stage"] == "0"){
                    header("location: StudentPage1.php");
                }else if($row["stage"] == "11"){
                    header("location: StudentPage11.php");
                }else if($row["stage"] == "2"){
                    $id_lead = $row['KFU_id'];
                    $_SESSION['idLeader'] = $id_lead;
                    header("location: StudentPage2.php");
                    $id_lead = $row['KFU_id'];
                    $_SESSION['idLeader'] = $id_lead;
                }else if($row["stage"] == "22"){
                    $id_lead = $row['KFU_id'];
                    $_SESSION['idLeader'] = $id_lead;
                    header("location: StudentPage22.php");
                }else if($row["stage"] == "3"){
                    $id_lead = $row['KFU_id'];
                    $_SESSION['idLeader'] = $id_lead;
                    header("location:StudentPage3.php");
                }
        }
           }
         
        }else{
            $errors['id']="Invalid id or password!";
        }
        
    }

    
   if(isset($_POST['cancel'])){
    session_start();
    session_unset();
    session_destroy();
    header('location: loginP.php');
}   

    if(isset($_POST['submit1'])){
        if(!empty($_POST["idleader"]) and !empty($_POST["id2"]) and !empty($_POST["id3"]) ){
            $filename = $_FILES['fileProject']['name'];
            $file = $_FILES['fileProject']['tmp_name'];
            $type = $_FILES['fileProject']['type'];
            $stage = "1";
            $id_lead = $_POST["idleader"];
            $_SESSION['idLeader'] = $id_lead;
            $id_2 = $_POST["id2"];
            $id_3 = $_POST["id3"];
            $title = $_POST["title"];
            $data = file_get_contents($_FILES['fileProject']['tmp_name']);
            if(!empty($_POST['id4'])){
                if(!empty($_POST['id5'])){
                    $id_4 = $_POST["id4"];
                    $id_5 = $_POST["id5"];
                    $check_id="select * from users where KFU_id IN( '".$id_lead."','".$id_2."','".$id_3."','".$id_4."','".$id_5."')";
                $result=mysqli_query($conn,$check_id);
                if(mysqli_num_rows($result) == 5){
                    $stmt = $dbh->prepare("insert into projectinfo (id_leader,id_2,id_3,id_4,id_5,project_title,name_file,mime,data,project_stage) values (?,?,?,?,?,?,?,?,?,?)");
                    $stmt->bindParam(1,$id_lead);
                    $stmt->bindParam(2,$id_2);
                    $stmt->bindParam(3,$id_3);
                    $stmt->bindParam(4,$id_4);
                    $stmt->bindParam(5,$id_5);
                    $stmt->bindParam(6,$title);
                    $stmt->bindParam(7,$filename);
                    $stmt->bindParam(8,$type);
                    $stmt->bindParam(9,$data);
                    $stmt->bindParam(10,$stage);
                    $stmt->execute();
                    $update_data = "UPDATE `users` SET `stage` = 11 where `KFU_id` = '".$id_lead."'";
                    $run_query = mysqli_query($conn, $update_data);
                    if($run_query){
                    header("location: StudentPage11.php");
                }
                }
                else{
                    $errors["idr"] = "<span class='error'>Id of team member does not exit !</span>";  
                  }
                    
                }else{
                    $id_4 = $_POST["id4"];
                $check_id="select * from users where KFU_id IN( '".$id_lead."','".$id_2."','".$id_3."','".$id_4."')";
                $result=mysqli_query($conn,$check_id);
                if(mysqli_num_rows($result) == 4){
                    $stmt = $dbh->prepare("insert into projectinfo (id_leader,id_2,id_3,id_4,project_title,name_file,mime,data,project_stage) values (?,?,?,?,?,?,?,?,?)");
                    $stmt->bindParam(1,$id_lead);
                    $stmt->bindParam(2,$id_2);
                    $stmt->bindParam(3,$id_3);
                    $stmt->bindParam(4,$id_4);
                    $stmt->bindParam(5,$title);
                    $stmt->bindParam(6,$filename);
                    $stmt->bindParam(7,$type);
                    $stmt->bindParam(8,$data);
                    $stmt->bindParam(9,$stage);
                    $stmt->execute();
                    $update_data = "UPDATE `users` SET `stage` = 11 where `KFU_id` = '".$id_lead."'";
                    $run_query = mysqli_query($conn, $update_data);
                    if($run_query){
                    header("location: StudentPage11.php");
                }
                }else{
                    $errors["idr"] = "<span class='error'>Id of team member does not exit !</span>";  
                  }
                    
                }
            }else{
                $student = "student";
                $state = "1";
                $check_id="select * from users where KFU_id IN( '".$id_lead."','".$id_2."','".$id_3."')";
                $result=mysqli_query($conn,$check_id);
                if(mysqli_num_rows($result) == 3){
                 $stmt = $dbh->prepare("insert into projectinfo (id_leader,id_2,id_3,project_title,name_file,mime,data,project_stage) values (?,?,?,?,?,?,?,?)");
                $stmt->bindParam(1,$id_lead);
                $stmt->bindParam(2,$id_2);
                $stmt->bindParam(3,$id_3);
                $stmt->bindParam(4,$title);
                $stmt->bindParam(5,$filename);
                $stmt->bindParam(6,$type);
                $stmt->bindParam(7,$data);
                $stmt->bindParam(8,$stage);
                $stmt->execute();
                $update_data = "UPDATE `users` SET `stage` = 11 where `KFU_id` = '".$id_lead."'";
                $run_query = mysqli_query($conn, $update_data);
                if($run_query){
                header("location: StudentPage11.php");
                }
                }else{
                  $errors["idr"] = "<span class='error'>Id of team member does not exit !</span>";  
                }
                
            }
            
        }else{
            $errors['idF']="<span class='error'>You have select a minimum three student!</span>";
        }
    }


    if(isset($_POST['submit2'])){
        if(!empty($_POST['radio'])){
            $id_lead = $_SESSION['idLeader'];
        $supervisor_id = $_POST['radio'];
        $update_data = "UPDATE `projectinfo` SET `supervisor_id` = '".$supervisor_id."' where `id_leader` = '".$id_lead."'";
        $run_query = mysqli_query($conn, $update_data);
        if($run_query){
            $update_data = "UPDATE `users` SET `stage` = '22' where `KFU_id` = '".$id_lead."'";
                    $run_query = mysqli_query($conn, $update_data);
                    if($run_query){
                        header("location: StudentPage22.php");
                }
            
            }
        }else{
            $errors['newUser']="<span class='error'>You must choose supervisor!</span>";
        }
        

    }
    if(isset($_POST['add'])){
        $newId = $_POST['newuserId'];
        $user_type = $_POST['radio'];
        $check_id="select * from users where KFU_id = '".$newId."' ";
        $result=mysqli_query($conn,$check_id);
        if(mysqli_num_rows($result) == 0){
            if($user_type == 'student'){
                $newEmail = $newId."@student.kfu.edu.sa";
                $insert = "INSERT INTO `users` (KFU_id,Email,user_type) values('".$newId."','".$newEmail."','".$user_type."') ";
                $run_query = mysqli_query($conn, $insert);
                if($run_query){
                    $errors['newId']="<span class='done'>student added successfully!</span>";
                    }
            }else if($user_type == 'supervise'){
                $username = $_POST['username'];
                $newEmail = $username."@kfu.edu.sa";
                $check_username="select * from users where Email = '".$newEmail."' ";
                $result=mysqli_query($conn,$check_username);
                if(mysqli_num_rows($result) == 0){
                    $insert = "INSERT INTO `users` (KFU_id,Email,user_type) values('".$newId."','".$newEmail."','".$user_type."') ";
                    $run_query = mysqli_query($conn, $insert);
                    if($run_query){
                    $errors['newId']="<span class='done'>supervisor added successfully!</span>";
                    }  
                }else{
                    $errors['newEMF']="<span class='error'>The id is already in the database!</span>";
                }
                
            }
            
            
        }else{
            $errors['newIdF']="<span class='error'>The id is already in the database!</span>";
        }
        }
    
?>