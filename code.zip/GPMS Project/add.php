<?php include_once "controllData.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        button{
                background: none;
	            color: inherit;
	            border: none;
	            padding: 0;
                margin:0;
	            font: inherit;
	            cursor: pointer;
	            outline: inherit;
            }
            .exitIcon{
                
                width:17%;
                float:right;
                padding-right:10px;
                margin:0;
            }
        body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #6E8EC4;
  padding: 10px;
}

.topnav p {
font-family: Verdana, Geneva, Tahoma, sans-serif;
  float: left;
  color: #f2f2f2;
  text-align: center;
  margin: 7px 0% 0% 7px;
  text-decoration: none;
  font-size: 19px;
}   
.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

/* Sidebar links */
.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}

/* Active/current link */


/* Links on mouse-over */
.sidebar a:hover {
  background-color: #555;
  color: white;
}

/* Page content. The value of the margin-left property should match the value of the sidebar's width property */
div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: 1000px;
}

/* On screens that are less than 700px wide, make the sidebar into a topbar */
@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

/* On screens that are less than 400px, display the bar vertically, instead of horizontally */
@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}
    .title{
      position: relative;
      text-align: center;
      justify-content: center;
      font-size:180%;
      margin: 0;
      padding:2% 40%;
      top:3%;
      background-color: #f1f1f1;
      
      
    }
    .position{
      position: relative;
      top:10%;
      left:35%;
    }
    .input-field{
  width: 20%;
  padding: 10px 0;
  margin: 5px 0;
  border-left: 0;
  border-top: 0;
  border-right: 0;
  border-bottom: 1px solid #999;
  outline: none;
  background: transparent;
}
.submit-btn{
    width: 20%;
    transition: 0.3s;
    padding: 10px 0;
    cursor: pointer;
    display: block;
    margin: 30px 0;
    background: #6E8EC4;
    border: 0;
    outline: none;
    border-radius: 30px;
    color: #fff;
    font-size: 20px;
}
.submit-btn:hover{
    text-decoration: none;
     background-color: #ffffff;
     color: #6E8EC4;
     padding: 8.5px 0;
    border: none;
    outline: 1px solid #010101;
    }
    #dropbtn{
                font-size:15px;
                background-color: #F0F0F0;
                color: #000000;
                padding: 4px;
                border-radius: 10px;
                
                
            }

            .dropdown {
            position: relative;
            display: inline-block;
            }

.dropdown-content {
  display: none;
  position: absolute;
  margin-bottom:50px;
  background-color: #f1f1f1;
  width: 300%;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
            .chooseSuper{
            font-size: 18px;
            text-align: center;
            margin-bottom:50px;
            }
            .container {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 18px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.container input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

/* Create a custom radio button */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #C0C0C0;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.container input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.container .checkmark:after {
 	top: 9px;
	left: 9px;
	width: 8px;
	height: 8px;
	border-radius: 50%;
	background: white;
}
.error{
                position: relative;
                text-align: center;
                color: #FF0000;
                font-weight: bold;
                font-size: 15px;
                padding-bottom: 10px;
            }
            .done{
                position: relative;
                text-align: center;
                color: #228B22;
                font-weight: bold;
                font-size: 15px;
                padding-bottom: 10px;
            }
            #suptext{
              display: none;
            }
    </style>
</head>
<body>
<form action="#" method="POST">
<div class="topnav">
<?php 
            $name = $_SESSION["Fname"];
            
            echo "<p> Welcome ".$name." </p> ";
            ?>
    <button style="float:right" type="submit"  name="cancel" class="exitButton">
    <a href="#"> <img class="exitIcon" src="exit2.png" alt="Exit" > </a>
    </button>
</div>
<div class="sidebar">
  <a href="adminP1.php">Proposed Projects</a>
  <a href="finalState.php">Final Accept Projects</a>
  <a href="approved.php">Approved Projects</a>
  <a href="prev.php">Previous Projects</a>
  <a href="add.php">Add Users</a>
  
</div>

<!-- Page content -->
<div class="content">
 <span class="title">Add Users </span>
 <div class="position">
  <input type="text" name="newuserId" class="input-field" placeholder="New User ID" ><br>
 <div class="choose">
                <span>User type</span>
                <div class="dropdown">
                <button id="dropbtn">choose</button>
                <div class="dropdown-content">
                  
                      <label class="container"> student
                     <input id="no" type="radio" name="radio" value="student" onclick="ShowHideInput()" checked="checked">
                      <span class="checkmark"></span>
                      </label>
                      <hr>
                      <label class="container"> supervise
                     <input id="super" type="radio" name="radio" value="supervise" onclick="ShowHideInput()">
                      <span class="checkmark"></span>
                      </label>
                      <hr>
                
                </div>
                </div>
                <br> <input id="suptext"type="text" name="username" class="input-field" placeholder="New Username" >
            </div>
            <?php 
            foreach($errors as $error){
            echo $error;
                                    }
                ?>
 <br><button type="submit" name="add" class="submit-btn">ADD</button>
 </div>
 
</div>
</form>
<script>
  function ShowHideInput() {
            var supercheck = document.getElementById("super");
            var superText = document.getElementById("suptext");
            superText.style.display = supercheck.checked ? "block" : "none";
        }
</script>
</body>
</html>