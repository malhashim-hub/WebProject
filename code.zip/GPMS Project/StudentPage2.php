<?php include_once "controllData.php"?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        button{
                background: none;
	            color: inherit;
	            border: none;
	            padding: 0;
                margin:0;
	            font: inherit;
	            cursor: pointer;
	            outline: inherit;
            }
            .exitIcon{
                
                width:17%;
                float:right;
                padding-right:10px;
                margin:0;
            }
        body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #6E8EC4;
  padding: 10px;
}

.topnav p {
font-family: Verdana, Geneva, Tahoma, sans-serif;
  float: left;
  color: #f2f2f2;
  text-align: center;
  margin: 7px 0% 0% 7px;
  text-decoration: none;
  font-size: 19px;
}   
.img{
    
    background-position: center;
    background-repeat: no-repeat;
    position: relative;
    background-size: cover;
    width: 100%
    
    
}
.textImg1{
    position: absolute;
    top: 15%;
    left: 4.5%;
    color: #fff;
    font-size: 35px;
    
}
.textImg2{
    position: absolute;
    top: 22.5%;
    left: 4.5%;
    color: #fff;
    font-size: 35px;
    
}
.stepper-wrapper {
  margin-top: auto;
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  padding-top:20px;
}
.stepper-item {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  flex: 1;

  @media (max-width: 768px) {
    font-size: 12px;
  }
}

.stepper-item::before {
  position: absolute;
  content: "";
  border-bottom: 2px solid #ccc;
  width: 100%;
  top: 20px;
  left: -50%;
  z-index: 2;
}

.stepper-item::after {
  position: absolute;
  content: "";
  border-bottom: 2px solid #ccc;
  width: 100%;
  top: 20px;
  left: 50%;
  z-index: 2;
}

.stepper-item .step-counter {
  position: relative;
  z-index: 5;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #ccc;
  margin-bottom: 6px;
}

.stepper-item.active {
  font-weight: bold;
}

.stepper-item.completed .step-counter {
  background-color: #4bb543;
}

.stepper-item.completed::after {
  position: absolute;
  content: "";
  border-bottom: 2px solid #4bb543;
  width: 100%;
  top: 20px;
  left: 50%;
  z-index: 3;

}

.stepper-item:first-child::before {
  content: none;
}
.stepper-item:last-child::after {
  content: none;
}
        
.submit-btn{
            position: relative;
            text-align: center;
            width: 22%;
            padding: 8.5px 0;
            cursor: pointer;
            margin: 5px 0;
            background: #6E8EC4;
            border: 0;
            outline: none;
            border-radius: 30px;
            color: #fff;
            font-size: 20px;
            margin-top:15px;
            transition: 0.3s;
            align-items: center;
            margin:1% 39%;
            margin-bottom:20%;
            }
            .submit-btn:hover{
            text-decoration: none;
             background-color: #ffffff;
             color: #6E8EC4;
             padding: 8.5px 0;
            border: none;
            outline: 1px solid #010101;
            }
            .message{
            font-family: sans-serif;
            font-size: 18px;
            font-weight: bold;
            background: #BDEBAA;
            text-align: center;
            margin:5% 27%;
            padding:10px;
            justify-content: center;
            border-radius: 10px;
            }
            #dropbtn{
                font-size:15px;
                background-color: #F0F0F0;
                color: #000000;
                padding: 4px;
                border-radius: 10px;
                
                
            }

            .dropdown {
            position: relative;
            display: inline-block;
            }

.dropdown-content {
  display: none;
  position: absolute;
  margin-bottom:50px;
  background-color: #f1f1f1;
  width: 650%;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
            .chooseSuper{
            font-size: 18px;
            text-align: center;
            margin-bottom:50px;
            }
            .container {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default radio button */
.container input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
}

/* Create a custom radio button */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #C0C0C0;
  border-radius: 50%;
}

/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the radio button is checked, add a blue background */
.container input:checked ~ .checkmark {
  background-color: #2196F3;
}

/* Create the indicator (the dot/circle - hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the indicator (dot/circle) when checked */
.container input:checked ~ .checkmark:after {
  display: block;
}

/* Style the indicator (dot/circle) */
.container .checkmark:after {
 	top: 9px;
	left: 9px;
	width: 8px;
	height: 8px;
	border-radius: 50%;
	background: white;
}
    </style>
</head>
<body>
<form action="#" method="POST">
<div class="topnav">
            <?php 
            $uname = $_SESSION["Fname"];
            
            echo "<p> Welcome ".$uname." </p> ";
            ?>
    <button style="float:right" type="submit"  name="cancel" class="exitButton">
    <a href="#"> <img class="exitIcon" src="exit2.png" alt="Exit" > </a>
    </button>
</div>
<div class="header">
    <img src="collegeImg.png" alt="" class="img">
    <h1 class="textImg1"> Computer Science and information <br> </h1>
    <h1 class="textImg2"> technology College </h1>
</div>
<div class="stepper-wrapper">
<div class="stepper-item completed">
    <div class="step-counter">1</div>
    <div class="step-name">First Stage</div>
  </div>
  <div class="stepper-item">
    <div class="step-counter">2</div>
    <div class="step-name">Second Stage</div>
  </div>
</div>
            <div class="message">
                <span>The Proposal project has been Accepted in the First Stage</span>
            </div>
            <div class="chooseSuper">
                <span>Please choose one supervisor to<br>supervise your project</span>
                <div class="dropdown">
                <button id="dropbtn">choose</button>
                <div class="dropdown-content">
                  <?php
                  $sql = "SELECT KFU_id,Fname , Lname FROM `users` WHERE `user_type` = 'supervisor'";
                  $result=mysqli_query($conn,$sql);
                  if($result->num_rows > 0){
                    while($row = $result->fetch_assoc()){
                      echo '<label class="container">'.$row["Fname"].' '.$row["Lname"].'';
                      echo '<input type="radio" name="radio" value="'.$row["KFU_id"].'"> ';
                      echo '<span class="checkmark"></span>';
                      echo '</label>';
                      echo '<hr>';
                    }
                  }else{
                    echo "No Aupervisor Available";
                }
                $conn->close();
                  ?>
                
                
                </div>
                </div>
                
            </div>
            <?php 
            foreach($errors as $error){
            echo $error;
                                    }
                ?>
            <input type="submit" class="submit-btn" name="submit2" value="SUBMIT">
            </form>
</body>
</html>