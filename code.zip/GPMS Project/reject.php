<?php

require "config.php";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer\src\Exception.php';
require 'PHPMailer\src\PHPMailer.php';
require 'PHPMailer\src\SMTP.php';

$dbh = new PDO("mysql:host=localhost;dbname=GPMSDB","root","");
    $id = isset($_GET['id_project'])? $_GET['id_project'] :"";
    $stat = $dbh->prepare("SELECT * FROM  projectinfo WHERE id_project = ?");
    $stat->bindParam(1,$id);
    $stat->execute();
    $row = $stat->fetch();
    $idleader = $row['id_leader'];
    
    //$sql = "SELECT * FROM  projectinfo WHERE id_project = ?";
    //$result=mysqli_query($conn,$sql);
    //$stat = $dbh->prepare("SELECT * FROM  projectinfo WHERE id_project = ?");
    $stat = $dbh->prepare("DELETE FROM `projectinfo` where id_project =?");
    $stat->bindParam(1,$id);
    $stat->execute();
        header('location: adminP1.php');
            $sql = "SELECT * from `users` where KFU_id = ".$idleader." ";
            $run_query = mysqli_query($conn, $sql);
            if(mysqli_num_rows($run_query)>0){
            $row=mysqli_fetch_array($run_query);
            $leadEmail = $row['Email'];
            $mail = new PHPMailer(true);
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'college.kfu.cs@gmail.com';
                $mail->Password = 'vuutcudstdixnumq';
                $mail->SMTPSecure = 'ssl';
                $mail->Port='465';
                $mail->SMTPKeepAlive = true;
                $mail->Mailer = "smtp";
                $mail->isSMTP();
                $mail->CharSet = 'utf-8';  
                $mail->SMTPDebug  = 0;  
                $mail->setFrom('college.kfu.cs@gmail.com');
                $mail->addAddress($leadEmail);
                $mail->isHTML(true);
                $mail->Subject = "Proposed Projects";
                $mail->Body = "Your Proposed Projects has been rejected!";
                $mail->send();
            }
        

?>