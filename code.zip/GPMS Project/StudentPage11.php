<?php include_once "controllData.php"?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        button{
                background: none;
	            color: inherit;
	            border: none;
	            padding: 0;
                margin:0;
	            font: inherit;
	            cursor: pointer;
	            outline: inherit;
            }
            .exitIcon{
                
                width:17%;
                float:right;
                padding-right:10px;
                margin:0;
            }
        body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #6E8EC4;
  padding: 10px;
}

.topnav p {
font-family: Verdana, Geneva, Tahoma, sans-serif;
  float: left;
  color: #f2f2f2;
  text-align: center;
  margin: 7px 0% 0% 7px;
  text-decoration: none;
  font-size: 19px;
}   
.img{
    
    background-position: center;
    background-repeat: no-repeat;
    position: relative;
    background-size: cover;
    width: 100%
    
    
}
.textImg1{
    position: absolute;
    top: 15%;
    left: 4.5%;
    color: #fff;
    font-size: 35px;
    
}
.textImg2{
    position: absolute;
    top: 22.5%;
    left: 4.5%;
    color: #fff;
    font-size: 35px;
    
}
.stepper-wrapper {
  margin-top: auto;
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  padding-top:20px;
}
.stepper-item {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  flex: 1;

  @media (max-width: 768px) {
    font-size: 12px;
  }
}

.stepper-item::before {
  position: absolute;
  content: "";
  border-bottom: 2px solid #ccc;
  width: 100%;
  top: 20px;
  left: -50%;
  z-index: 2;
}

.stepper-item::after {
  position: absolute;
  content: "";
  border-bottom: 2px solid #ccc;
  width: 100%;
  top: 20px;
  left: 50%;
  z-index: 2;
}

.stepper-item .step-counter {
  position: relative;
  z-index: 5;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #ccc;
  margin-bottom: 6px;
}

.stepper-item.active {
  font-weight: bold;
}

.stepper-item.completed .step-counter {
  background-color: #4bb543;
}

.stepper-item.completed::after {
  position: absolute;
  content: "";
  border-bottom: 2px solid #4bb543;
  width: 100%;
  top: 20px;
  left: 50%;
  z-index: 3;

}

.stepper-item:first-child::before {
  content: none;
}
.stepper-item:last-child::after {
  content: none;
}
 
            .message{
            font-family: sans-serif;
            font-size: 18px;
            font-weight: bold;
            background: #BDEBAA;
            text-align: center;
            margin:5% 25%;
            padding:12px;
            justify-content: center;
            border-radius: 10px;
            }
            #dropbtn{
                font-size:15px;
                background-color: #F0F0F0;
                color: #000000;
                padding: 4px;
                border-radius: 10px;
                
                
            }

    </style>
</head>
<body>
<form action="#" method="POST">
<div class="topnav">
<?php include_once "controllData.php";
            $uname = $_SESSION["Fname"];
            
            echo "<p> Welcome ".$uname." </p> ";
            ?>
    <button style="float:right" type="submit"  name="cancel" class="exitButton">
    <a href="#"> <img class="exitIcon" src="exit2.png" alt="Exit" > </a>
    </button>
</div>
<div class="header">
    <img src="collegeImg.png" alt="" class="img">
    <h1 class="textImg1"> Computer Science and information <br> </h1>
    <h1 class="textImg2"> technology College </h1>
</div>
<div class="stepper-wrapper">
<div class="stepper-item active">
    <div class="step-counter">1</div>
    <div class="step-name">First Stage</div>
  </div>
  <div class="stepper-item">
    <div class="step-counter">2</div>
    <div class="step-name">Second Stage</div>
  </div>
</div>
            <div class="message">
                <span>The Proposal project has been Sent to The Graduation Project Committee</span>
            </div>
            
            </form>
</body>
</html>