<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        button{
                background: none;
	            color: inherit;
	            border: none;
	            padding: 0;
                margin:0;
	            font: inherit;
	            cursor: pointer;
	            outline: inherit;
            }
            .exitIcon{
                
                width:17%;
                float:right;
                padding-right:10px;
                margin:0;
            }
        body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #6E8EC4;
  padding: 10px;
}

.topnav p {
font-family: Verdana, Geneva, Tahoma, sans-serif;
  float: left;
  color: #f2f2f2;
  text-align: center;
  margin: 7px 0% 0% 7px;
  text-decoration: none;
  font-size: 19px;
}   
.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

/* Sidebar links */
.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}

/* Active/current link */


/* Links on mouse-over */
.sidebar a:hover {
  background-color: #555;
  color: white;
}

/* Page content. The value of the margin-left property should match the value of the sidebar's width property */
div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: 1000px;
}

/* On screens that are less than 700px wide, make the sidebar into a topbar */
@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

/* On screens that are less than 400px, display the bar vertically, instead of horizontally */
@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}
    .title{
      position: relative;
      text-align: center;
      justify-content: center;
      font-size:180%;
      margin: 0;
      padding:2% 39%;
      top:3%;
      background-color: #f1f1f1;
      
      
    }
    #customers {
      position: relative;
      top:10%;
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #6E8EC4;
  color: white;
}
.buttonacc {
    display: block;
    width: 50px;
    height: 25px;
    background: #4CAF50;
    padding: 1px 2px;
    text-align: center;
    border-radius: 5px;
    color: white;
    text-decoration: none;
    line-height: 25px;
    margin-left:13px;
}
.buttonrej {
    display: block;
    width: 50px;
    height: 25px;
    background: #f44336;
    padding: 1px 2px;
    text-align: center;
    border-radius: 5px;
    color: white;
    text-decoration: none;
    line-height: 25px;
    margin-left:13px;
}
td {
  height: 20px;
  width: 80px;
  text-align: center;
  vertical-align: middle;
}
.buttondown {
    display: block;
    width: 80px;
    height: 25px;
    background: #4169E1;
    padding: 1px 2px;
    text-align: center;
    border-radius: 5px;
    color: white;
    text-decoration: none;
    line-height: 25px;
    margin-left:15px;
}
    </style>
</head>
<body>
<form action="#" method="POST">
<div class="topnav">
<?php include_once "controllData.php";
            $name = $_SESSION["Fname"];
            
            echo "<p> Welcome ".$name." </p> ";
            ?>
    <button style="float:right" type="submit"  name="cancel" class="exitButton">
    <a href="#"> <img class="exitIcon" src="exit2.png" alt="Exit" > </a>
    </button>
</div>
<div class="sidebar">
  <a href="adminP1.php">Proposed Projects</a>
  <a href="finalState.php">Final Accept Projects</a>
  <a href="approved.php">Approved Projects</a>
  <a href="prev.php">Previous Projects</a>
  <a href="add.php">Add Users</a>
</div>

<!-- Page content -->
<div class="content">
 <span class="title">Proposed Projects </span>
 <table id="customers">
  <tr>
    <th  style="text-align:center">project title</th>
    <th colspan="5"  style="text-align:center">team members</th>
    <th colspan="2"  style="text-align:center">state</th>
    <th  style="text-align:center">File Project</th>
  </tr>
    <?php
    $sql = "SELECT * FROM  projectinfo WHERE project_stage = '1'";
    //$result=mysqli_query($conn,$sql);
    $dbh = new PDO("mysql:host=localhost;dbname=GPMSDB","root","");
    $stat = $dbh->prepare($sql);
    $stat->execute();
    while($row = $stat->fetch()){
      echo "<tr>";
      echo "<td>".$row["project_title"]."</td>";
      echo "<td>".$row["id_leader"]."</td>";
      echo "<td>".$row["id_2"]."</td>";
      echo "<td>".$row["id_3"]."</td>";
      echo "<td>".$row["id_4"]."</td>";
      echo "<td>".$row["id_5"]."</td>";
      echo "<td><a class='buttonacc' target='_self' href='accept.php?id_project=".$row["id_project"]."'>Accept</a></td>";
      echo "<td><a class='buttonrej' target='_self' href='reject.php?id_project=".$row["id_project"]."'>Reject</a></td>";
      echo "<td><a class='buttondown' target='_blank' href='downloadFile.php?id_project=".$row["id_project"]."'>Download</a></td>";
    }
    ?>
  
  </table>
</div>
</form>
</body>
</html>