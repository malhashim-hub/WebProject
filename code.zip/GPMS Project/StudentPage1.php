<?php include_once "controllData.php"?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        button{
                background: none;
	            color: inherit;
	            border: none;
	            padding: 0;
                margin:0;
	            font: inherit;
	            cursor: pointer;
	            outline: inherit;
            }
            .exitIcon{
                
                width:17%;
                float:right;
                padding-right:10px;
                margin:0;
            }
        body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #6E8EC4;
  padding: 10px;
}

.topnav p {
font-family: Verdana, Geneva, Tahoma, sans-serif;
  float: left;
  color: #f2f2f2;
  text-align: center;
  margin: 7px 0% 0% 7px;
  text-decoration: none;
  font-size: 19px;
}   
.img{
    
    background-position: center;
    background-repeat: no-repeat;
    position: relative;
    background-size: cover;
    width: 100%
    
    
}
.textImg1{
    position: absolute;
    top: 15%;
    left: 4.5%;
    color: #fff;
    font-size: 35px;
    
}
.textImg2{
    position: absolute;
    top: 22.5%;
    left: 4.5%;
    color: #fff;
    font-size: 35px;
    
}
.stepper-wrapper {
  margin-top: auto;
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  padding-top:20px;
}
.stepper-item {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  flex: 1;

  @media (max-width: 768px) {
    font-size: 12px;
  }
}

.stepper-item::before {
  position: absolute;
  content: "";
  border-bottom: 2px solid #ccc;
  width: 100%;
  top: 20px;
  left: -50%;
  z-index: 2;
}

.stepper-item::after {
  position: absolute;
  content: "";
  border-bottom: 2px solid #ccc;
  width: 100%;
  top: 20px;
  left: 50%;
  z-index: 2;
}

.stepper-item .step-counter {
  position: relative;
  z-index: 5;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #ccc;
  margin-bottom: 6px;
}

.stepper-item.active {
  font-weight: bold;
}

.stepper-item.completed .step-counter {
  background-color: #4bb543;
}

.stepper-item.completed::after {
  position: absolute;
  content: "";
  border-bottom: 2px solid #4bb543;
  width: 100%;
  top: 20px;
  left: 50%;
  z-index: 3;

}

.stepper-item:first-child::before {
  content: none;
}
.stepper-item:last-child::after {
  content: none;
}
        .textId{
            margin-left:22%;
            margin-top:50px;
        }
        .input-field{
            
            width: 15%;
            padding: 10px 0;
            margin: 10px 22%;
            border-left: 0;
            border-top: 0;
            border-right: 0;
            border-bottom: 2px solid #999;
            outline: none;
            background: transparent;
            margin-bottom: 10px;
            }
            @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap");
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap');

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}

.container {
  height: 100vh;
  width: 100%;
  align-items: right;
  display: flex;
  justify-content: right;
  background-color: #fcfcfc;
}

.card {
  position: relative;
  border-radius: 10px;
  
  width: 600px;
  height: 260px;
  background-color: #ffffff;
  padding: 10px  30px 40px;
  margin-right:50px;
  top:-40%;
}

.card h3 {
  font-size: 22px;
  font-weight: 600;
  
}

.drop_box {
  margin: 10px 0;
  padding: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  border: 3px dotted #a3a3a3;
  border-radius: 5px;
}

.drop_box h4 {
  font-size: 16px;
  font-weight: 400;
  color: #2e2e2e;
}

.drop_box p {
  margin-top: 10px;
  margin-bottom: 20px;
  font-size: 12px;
  color: #a3a3a3;
}

.btn {
  text-decoration: none;
  background-color: #ffffff;
  color: #6E8EC4;
  padding: 10px 20px;
  border-radius: 10px;
  outline: none;
  transition: 0.3s;
}

.btn:hover{
  text-decoration: none;
  background-color: #ffffff;
  color: #6E8EC4;
  padding: 10px 20px;
  border: none;
  outline: 1px solid #010101;
}
.form input {
  margin: 10px 0;
  width: 100%;
  background-color: #e2e2e2;
  border: none;
  outline: none;
  padding: 12px 20px;
  border-radius: 4px;
}
.submit-btn{
            position: relative;
            top:0;
            transition: 0.3s;
            text-align: center;
            width: 50%;
            padding: 8.5px 0;
            cursor: pointer;
            margin: 10px 25%;
            background: #6E8EC4;
            border: 0;
            outline: none;
            border-radius: 30px;
            color: #fff;
            font-size: 20px;
            margin-top:50px;
            
            }
            .submit-btn:hover{
            text-decoration: none;
             background-color: #ffffff;
             color: #6E8EC4;
             padding: 8.5px 0;
            border: none;
            outline: 1px solid #010101;
            }
            .error{
                position: relative;
                text-align: center;
                color: #FF0000;
                font-weight: bold;
                font-size: 15px;
                padding-bottom: 10px;
            }
    </style>
</head>
<body>
      <form action="#" method="POST" enctype="multipart/form-data">
<div class="topnav">
<?php include_once "controllData.php";
            $uname = $_SESSION["Fname"];
            
            echo "<p> Welcome ".$uname." </p> ";
            ?>
          
    <button style="float:right" type="submit"  name="cancel" class="exitButton">
    <a href="#"> <img class="exitIcon" src="exit2.png" alt="Exit" > </a>
    </button>
</div>
<div class="header">
    <img src="collegeImg.png" alt="" class="img">
    <h1 class="textImg1"> Computer Science and information <br> </h1>
    <h1 class="textImg2"> technology College </h1>
</div>
<div class="stepper-wrapper">
<div class="stepper-item active">
    <div class="step-counter">1</div>
    <div class="step-name">First Stage</div>
  </div>
  <div class="stepper-item">
    <div class="step-counter">2</div>
    <div class="step-name">Second Stage</div>
  </div>
</div>
        <div class="inputId">
        <p class="textId">Please Enter Id's, You have select a minimum three student.</p>
        <input type="text"  id="email" name="title" class="input-field" placeholder="Project Title"><br>
        <input type="text"  id="email" name="idleader" class="input-field" placeholder="Id for Team Leader"><br>
        <input type="text"  id="email" name="id2" class="input-field" placeholder="Id for Second Student"><br>
        <input type="text"  id="email" name="id3" class="input-field" placeholder="Id for Third Student"><br>
        <input type="text"  id="email" name="id4" class="input-field" placeholder="Id for Fourth Student"><br>
        <input type="text"  id="email" name="id5" class="input-field" placeholder="Id for Fifth Student"><br>  
        </div>
        <div class="container">
  <div class="card">
    <h3>Upload File</h3>
    <div class="drop_box">
      <header>
        <h4>Select of Proposal File Here</h4>
      </header>
      <p>Files Supported: PDF, TEXT, DOC , DOCX</p>
      <input type="file"  accept=".doc,.docx,.pdf" class="btn" id="fileID" name="fileProject" >
      
    </div>
    <?php 
       foreach($errors as $error){
        echo $error;
         }
        ?>
    <input type="submit" class="submit-btn" name="submit1" value="SUBMIT">

  </div>
</div>

</form>
</body>
</html>