<?php
$dbh = new PDO("mysql:host=localhost;dbname=GPMSDB","root","");
$id = isset($_GET['id_project'])? $_GET['id_project'] :"";
$stat = $dbh->prepare("SELECT * FROM  projectinfo WHERE id_project = ?");
$stat->bindParam(1,$id);
$stat->execute();
$row = $stat->fetch();
$idleader = $row['id_leader'];
$stat = $dbh->prepare("UPDATE projectinfo SET `project_stage` = '5' where id_project =?");
$stat->bindParam(1,$id);
$stat->execute();
    header('location: adminP1.php');
?>