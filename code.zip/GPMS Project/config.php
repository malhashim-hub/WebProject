<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "GPMSDB";
  // Create connection
  $conn = mysqli_connect($servername, $username, $password,$dbname); // ----- 1
  // Check connection
  //$sql = "CREATE Database nawaf";
  //$ret = mysqli_query($conn, $sql);
  /*
  if ($conn){
    echo 'work';
  }else{
    echo "no";
  }*/
?>

