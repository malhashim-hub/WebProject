<?php require_once "sendEmail.php";?>
<!DOCTYPE html>
<html>
    <head>
        <title> Create Account Page </title>
        <style>
            html {
                background: url("Background.png") no-repeat center center fixed; 
                background-size: cover;
            }
            .form{
                display:block;
                text-align: center;

            }
            .box {
                border: 5px rgb(138, 24, 24);
                background-color: white;
                text-align: center;
                width: 380px;
                height: 485px;
                display: flex;
                justify-content: center;
                align-items: top;
                text-align: center;
                margin: 6% auto;
                border-radius: 10%;
                padding: 10px;
            }
            .box .content .title {
                position: relative;
                font-size: 105%;
                font-family:Verdana, Geneva, Tahoma, sans-serif;
                color: rgb(0, 0, 0);
                margin-top: 0;
                
            }
            .box .content .form #email {
                border-style:ridge;
                font-family: Verdana, Geneva, Tahoma, sans-serif;
                font-size: 105%;
            }
            .input-field{
            width: 80%;
            padding: 10px 0;
            margin: 5px 0;
            border-left: 0;
            border-top: 0;
            border-right: 0;
            border-bottom: 2px solid #999;
            outline: none;
            background: transparent;
            margin-bottom: 10px;
            }
            .exitIcon{
                
                width:10%;
                float:left;
                margin:0;
            }
            .submit-btn{
            text-align: center;
            width: 80%;
            padding: 8.5px 0;
            cursor: pointer;
            margin: 5px 0;
            background: #6E8EC4;
            border: 0;
            outline: none;
            border-radius: 30px;
            color: #fff;
            font-size: 20px;
            margin-top:15px;
            }
            button{
                background: none;
	            color: inherit;
	            border: none;
	            padding: 0;
	            font: inherit;
	            cursor: pointer;
	            outline: inherit;
            }
            .error{
                position: relative;
                text-align: center;
                color: #FF0000;
                font-weight: bold;
                font-size: 15px;
                padding-bottom: 10px;
            }
        </style>
    </head>
    <body>
        <div class="background"></div>
        
                <div class="form">
                    <form action="#" method="POST">
                <div class="box">

                    <div class="content">
                    <button  type="submit" name="cancel">
                    <img  class="exitIcon"src="exit.png" alt="Exit">
                    </button>
                    <div class="title">
                    <h1> Create Account </h1>
                </div>
                        <input type="text"  id="email" name="userEmail" class="input-field" placeholder="Enter your Email"><br>
                        <?php 
                                    foreach($errors as $error){
                                        echo $error;
                                    }
                                ?>
                        <input type="submit" class="submit-btn" name="next_1" value="NEXT">
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>