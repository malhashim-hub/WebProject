<?php include_once "sendEmail.php";?>
<!DOCTYPE html>
<html>
    <head>
        <title> Create Account Page </title>
        <style>
            html {
                background: url("Background.png") no-repeat center center fixed; 
                background-size: cover;
            }
            .form{
                display:block;
                text-align: center;

            }
            .box {
                border: 5px rgb(138, 24, 24);
                background-color: white;
                text-align: center;
                width: 380px;
                height: 485px;
                display: flex;
                justify-content: center;
                align-items: top;
                text-align: center;
                margin: 6% auto;
                border-radius: 10%;
                padding: 10px;
            }
            .box .content .title {
                position: relative;
                font-size: 105%;
                font-family:Verdana, Geneva, Tahoma, sans-serif;
                color: rgb(0, 0, 0);
                margin-top: 0;
                
            }
            .box .content .form #email {
                border-style:ridge;
                font-family: Verdana, Geneva, Tahoma, sans-serif;
                font-size: 105%;
            }
            .input-field{
            width: 80%;
            padding: 10px 0;
            margin: 5px 0;
            border-left: 0;
            border-top: 0;
            border-right: 0;
            border-bottom: 2px solid #999;
            outline: none;
            background: transparent;
            margin-bottom: 10px;
            }
            .exitIcon{
                
                width:10%;
                float:left;
                margin:0;
            }
            .submit-btn{
            text-align: center;
            width: 80%;
            padding: 8.5px 0;
            cursor: pointer;
            margin: 5px 0;
            background: #6E8EC4;
            border: 0;
            outline: none;
            border-radius: 30px;
            color: #fff;
            font-size: 20px;
            margin-top:15px;
            }
            button{
                background: none;
	            color: inherit;
	            border: none;
	            padding: 0;
	            font: inherit;
	            cursor: pointer;
	            outline: inherit;
            }
            .error{
                position: relative;
                text-align: center;
                color: #FF0000;
                font-weight: bold;
                font-size: 15px;
                padding-bottom: 10px;
            }
            .id{
                font-size: 15px;
                color: #6E8EC4;
            }
            .spanInfo{
                color: rgb(0, 0, 0);
                font-size: 17px;
            }
            #message {
    display: none;
    position: absolute;
    width: 250px;
    padding: 15px;
    background: #fff;
    font-size: 11px;
    border-radius: 5px;
    margin-left: 320px;
    margin-top: -184px;
    box-shadow:-10px 0px 10px 1px #AAAAAA;
    border-radius: 5%;
}

#message h3 {
    font-size: 15px;
}

#message p {
    padding: 5px 18px;
    font-size: 16px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
    color: green;
}


/* Add a red text color and an "x" icon when the requirements are wrong  */
.invalid {
    color: red;
}
form i {
    margin-left: -22px;
    cursor: pointer;
}

        </style>
    </head>
    <body>
        <div class="background"></div>
        
                <div class="form">
                    <form action="newUserInfo.php" method="POST">
                <div class="box">

                    <div class="content">
                    <button  type="submit" name="cancel">
                    <img  class="exitIcon"src="exit.png" alt="Exit">
                    </button>
                    <div class="title">
                    <h1> Create Account </h1>
                </div>  <?php  
                        include_once "sendEmail.php";
                        $userEmail = $_SESSION['userEmail'];
                        $sql="select KFU_id from users where Email= '".$userEmail."' ";
                        $result=mysqli_query($conn,$sql);
                        if(mysqli_num_rows($result)>0){
                        $row=mysqli_fetch_array($result);
                        $kfuId = $row["KFU_id"];
                        echo "<span class='spanInfo'>Your university id is  <span class='id'>".$kfuId."</span><br>Please Fill all Fields</span>";
                        }
                        ?>

                        <input type="text"  id="email" name="fname" class="input-field" placeholder="First Name"><br>
                        <input type="text"  id="email" name="lname" class="input-field" placeholder="Last Name"><br>
                        <input type="password"  id="e" name="Npass" class="input-field" placeholder="New password"><br>
                        <i class="bi bi-eye-slash" id="togglePassword"></i><br/>
                        <div id="message">
                            <h3>Password must contain the following:</h3>
                            <p id="letter" class="invalid"><b>lowercase</b> letter</p>
                            <p id="capital" class="invalid"><b>capital (uppercase)</b> letter</p>
                            <p id="number" class="invalid"> <b>number</b></p>
                            <p id="length" class="invalid">Minimum <b>6 characters</b></p>
                        </div>
                        <input type="password"  id="email" name="Cpass" class="input-field" placeholder="Confirm password"><br>
                        <?php 
                            foreach($errors as $error){
                            echo $error;
                            }
                            ?>
                        <input type="submit" id="chan" class="submit-btn" name="save" value="SAVE">
                        
                      
                    </form>
                </div>
            </div>
        </div>
        <script>
            
const myInput = document.getElementById("e");
const letter = document.getElementById("letter");
const capital = document.getElementById("capital");
const number = document.getElementById("number");
const length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function () {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function () {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function () {
  // Validate lowercase letters
  const lowerCaseLetters = /[a-z]/g;
  if (myInput.value.match(lowerCaseLetters)) {
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }

  // Validate capital letters
  const upperCaseLetters = /[A-Z]/g;
  if (myInput.value.match(upperCaseLetters)) {
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  const numbers = /[0-9]/g;
  if (myInput.value.match(numbers)) {
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }

  // Validate length
  if (myInput.value.length > 5) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}

const togglePassword = document.querySelector('#togglePassword');
const password = document.querySelector('#e');

togglePassword.addEventListener('click', function (e) {
    // toggle the type attribute
    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
    password.setAttribute('type', type);
    // toggle the eye / eye slash icon
    this.classList.toggle('bi-eye');
});

var mov = document.getElementById("chan");
            mov.addEventListener("mouseover", function(){
                this.style="background-color: whitesmoke; color:#6E8EC4; border: solid 1px #6E8EC4";
                
            });
            mov.addEventListener("mouseout", function(){
                this.style="";
            });

            
        </script>
    </body>
</html>