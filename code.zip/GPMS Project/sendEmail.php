<?php
 require "config.php";
 session_start();

$userEmail2="";
$userEmail="";
$Email = array();
$errors = array();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer\src\Exception.php';
require 'PHPMailer\src\PHPMailer.php';
require 'PHPMailer\src\SMTP.php';
if(isset($_POST['next_2'])){ //for Verification email from change pass
    $userEmail2 = $_POST['userEmail_2'];
    $_SESSION['userEmail2'] = $userEmail2;
    $sql="select * from users where Email= '".$userEmail2."' ";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) > 0){
        $row=mysqli_fetch_array($result);
        if($row){
            $code = rand(999999, 111111);
            $update_data = "UPDATE `users` SET `code`='".$code."' WHERE `Email` = '".$userEmail2."'";
            $run_query = mysqli_query($conn, $update_data);
            if($run_query){
                $mail = new PHPMailer(true);
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'college.kfu.cs@gmail.com';
                $mail->Password = 'vuutcudstdixnumq';
                $mail->SMTPSecure = 'ssl';
                $mail->Port='465';
                $mail->SMTPKeepAlive = true;
                $mail->Mailer = "smtp";
                $mail->isSMTP();
                $mail->CharSet = 'utf-8';  
                $mail->SMTPDebug  = 0;  
                $mail->setFrom('college.kfu.cs@gmail.com');
                $mail->addAddress($userEmail2);
                $mail->isHTML(true);
                $mail->Subject = "Verification code";
                $mail->Body = "Your Verification code is ".$code ."";
                $mail->send();
                header("location:emailcode.php"); 
            }
        }
    }else{
        $errors["no"] = "<span class='error'>This email address does not exist!</span>";
    }
}

if(isset($_POST['next_1'])){ //for Verification email from new user
    $userEmail = $_POST['userEmail'];
    $_SESSION['userEmail'] = $userEmail;
    $sql="select user_type from users where Email= '".$userEmail."' ";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) > 0){
        $row=mysqli_fetch_array($result);
        if($row["user_type"]=="student" or $row["user_type"]=="supervisor"){
            $code = rand(999999, 111111);
            $update_data = "UPDATE `users` SET `code`='".$code."' WHERE `Email` = '".$userEmail."'";
            $run_query = mysqli_query($conn, $update_data);
            if($run_query){
                $mail = new PHPMailer(true);
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'college.kfu.cs@gmail.com';
                $mail->Password = 'vuutcudstdixnumq';
                $mail->SMTPSecure = 'ssl';
                $mail->Port='465';
                $mail->SMTPKeepAlive = true;
                $mail->Mailer = "smtp";
                $mail->isSMTP();
                $mail->CharSet = 'utf-8';  
                $mail->SMTPDebug  = 0;  
                $mail->setFrom('college.kfu.cs@gmail.com');
                $mail->addAddress($userEmail);
                $mail->isHTML(true);
                $mail->Subject = "Verification code";
                $mail->Body = "Your Verification code is ".$code ."";
                $mail->send();
                header("location:emailcode2.php"); 
            }
        }
    }else{
        $errors["no2"] = "<span class='error'>This email address does not exist!</span>";
    }
}

if(isset($_POST['next_3'])){  //for Verification Code from change pass
        
                
        $uscode = "".$_POST['c_1']."".$_POST['c_2']."".$_POST['c_3']."".$_POST['c_4']."".$_POST['c_5']."".$_POST['c_6']."";
          
        $userEmail2 = $_SESSION['userEmail2'];
        $sql="select code from users where Email= '".$userEmail2."' ";
        $result=mysqli_query($conn,$sql);
        if(mysqli_num_rows($result)>0){
        $row=mysqli_fetch_array($result);
        $dbcode = $row["code"];
        if($uscode == $dbcode){
            header('location: changePass.php');
        }else{
            $errors["codeF"] = "<span class='error'>Invalid code. Try again!</span>";
        }   
    }   
    }
    if(isset($_POST['next_4'])){  //for Verification Code from new user
        
                
        $uscode = "".$_POST['c_1']."".$_POST['c_2']."".$_POST['c_3']."".$_POST['c_4']."".$_POST['c_5']."".$_POST['c_6']."";
          
        $userEmail = $_SESSION['userEmail'];
        $sql="select code from users where Email= '".$userEmail."' ";
        $result=mysqli_query($conn,$sql);
        if(mysqli_num_rows($result)>0){
        $row=mysqli_fetch_array($result);
        $dbcode = $row["code"];
        if($uscode == $dbcode){
            header('location: newUserInfo.php');
        }else{
            $errors["codeF"] = "<span class='error'>Invalid code. Try again!</span>";
        }   
    }   
    }
    if(isset($_POST['cancel'])){
        session_start();
        session_unset();
        session_destroy();
        header('location: loginP.php');
    }

    if(isset($_POST['change'])){ //fro change pass page
        $userEmail2 = $_SESSION['userEmail2'];
        $Npass = $_POST['Npass'];
        $Cpass = $_POST['Cpass'];
        if($Npass == $Cpass){
        $encpass = password_hash($Npass, PASSWORD_BCRYPT); 
        $update_data = "UPDATE `users` SET `password`='".$encpass."' WHERE `Email` = '".$userEmail2."'";
        $run_query = mysqli_query($conn, $update_data);
        if($run_query){
        
        header('location: passDone.php');
        }else{
            $errors["passFF"] = "<span class='error'>Failed to change your password!</span>";
        }

        }else{
            $errors["passF"] = "<span class='error'>Confirm password not matched!</span>";
        }

    }

    if(isset($_POST['save'])){
               
        $Npass = $_POST['Npass'];
        $Cpass = $_POST['Cpass'];
        if($Npass == $Cpass){
        $userEmail = $_SESSION['userEmail']; 
        $encpass = password_hash($Npass, PASSWORD_BCRYPT);   
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $update_data = "UPDATE `users` SET `Fname`='".$fname."',`Lname`='".$lname."',`password`='".$encpass."' WHERE `Email` = '".$userEmail."'";
        $run_query = mysqli_query($conn, $update_data);
        if($run_query){
            
            header('location: saveDone.php');
        }else{
            $errors["passFF"] = "<span class='error'>Failed to change your password!</span>";
        }
    
        }else{
            $errors["passF"] = "<span class='error'>Confirm password not matched!</span>";
        }      
                           
    }

    
    
    


?>