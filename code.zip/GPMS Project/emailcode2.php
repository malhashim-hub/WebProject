<?php include_once "sendEmail.php";?>
<!DOCTYPE html>
<html>
    <head>
        <title> Create Account Page </title>
        <style>
            html {
                background: url("Background.png") no-repeat center center fixed; 
                background-size: cover;
            }
            .form{
                display:block;
                text-align: center;

            }
            .box {
                border: 5px rgb(138, 24, 24);
                background-color: white;
                text-align: center;
                width: 380px;
                height: 485px;
                display: flex;
                justify-content: center;
                align-items: top;
                text-align: center;
                margin: 6% auto;
                border-radius: 10%;
                padding: 10px;
            }
            .box .content .title {
                position: relative;
                font-size: 105%;
                font-family:Verdana, Geneva, Tahoma, sans-serif;
                color: rgb(0, 0, 0);
                margin-top: 0;
                
            }
            .box .content .form #email {
                border-style:ridge;
                font-family: Verdana, Geneva, Tahoma, sans-serif;
                font-size: 105%;
            }
            .input-field{
            width: 60%;
            padding: 10px 0;
            margin: 5px 0;
            border-left: 0;
            border-top: 0;
            border-right: 0;
            border-bottom: 2px solid #999;
            outline: none;
            background: transparent;
            margin-bottom: 10px;
            }
            .exitIcon{
                
                width:10%;
                float:left;
                margin:0;
            }
            .submit-btn{
            text-align: center;
            width: 80%;
            padding: 8.5px 0;
            cursor: pointer;
            margin: 5px 0;
            background: #6E8EC4;
            border: 0;
            outline: none;
            border-radius: 30px;
            color: #fff;
            font-size: 20px;
            margin-top:15px;
            }
            button{
                background: none;
	            color: inherit;
	            border: none;
	            padding: 0;
	            font: inherit;
	            cursor: pointer;
	            outline: inherit;
            }
            .error{
                position: relative;
                text-align: center;
                color: #FF0000;
                font-weight: bold;
                font-size: 15px;
                padding-bottom: 10px;
            }
            .spanInfo{
              position: relative;
                color: rgb(0, 0, 0);
                font-size: 17px;
                
            }
            input[type=number] {
          height: 45px;
          width: 45px;
          font-size: 25px;
          text-align: center;
          border: 1px solid #000000;
          margin-top: 16px;
          margin-bottom: 8px;
      }
      input[type=number]::-webkit-inner-spin-button,
      input[type=number]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }
      .id{
        font-size: 15px;
        color: #6E8EC4;
            }
        </style>
    </head>
    <body>
        <div class="background"></div>
        
                <div class="form">
                    <form action="#" method="POST">
                <div class="box">

                    <div class="content">
                    <button  type="submit" name="cancel">
                    <img  class="exitIcon"src="exit.png" alt="Exit">
                    </button>
                    <div class="title">
                    <h2> Verification Code </h2>
                    <?php
                    include_once "sendEmail.php";
                    $userEmail = $_SESSION['userEmail'];
                    echo "<span class='spanInfo'> Verification code has been sent to <br>  <span class='id'>".$userEmail."</span> Please Enter verification code </span>";
                    ?>
                </div>
                <input id="codeBox1" type="number" name="c_1" maxlength="1" onkeyup="onKeyUpEvent(1, event)" onfocus="onFocusEvent(1)"/>
                <input id="codeBox2" type="number" name="c_2" maxlength="1" onkeyup="onKeyUpEvent(2, event)" onfocus="onFocusEvent(2)"/>
                <input id="codeBox3" type="number" name="c_3" maxlength="1" onkeyup="onKeyUpEvent(3, event)" onfocus="onFocusEvent(3)"/>
                <input id="codeBox4" type="number" name="c_4" maxlength="1" onkeyup="onKeyUpEvent(4, event)" onfocus="onFocusEvent(4)"/>
                <input id="codeBox5" type="number" name="c_5" maxlength="1" onkeyup="onKeyUpEvent(5, event)" onfocus="onFocusEvent(5)"/>
                <input id="codeBox6" type="number" name="c_6" maxlength="1" onkeyup="onKeyUpEvent(6, event)" onfocus="onFocusEvent(6)"/><br> 
                <?php 
                                    foreach($errors as $error){
                                        echo $error;
                                    }
                                ?>
                <input type="submit" class="submit-btn" name="next_4" value="CONFIRM">
                       

                    </form>
                    
                </div>
            </div>
        </div>
        <script>
      function getCodeBoxElement(index) {
        return document.getElementById('codeBox' + index);
      }
      function onKeyUpEvent(index, event) {
        const eventCode = event.which || event.keyCode;
        if (getCodeBoxElement(index).value.length === 1) {
          if (index !== 6) {
            getCodeBoxElement(index+ 1).focus();
          } else {
            getCodeBoxElement(index).blur();
            // Submit code
            console.log('submit code ');
          }
        }
        if (eventCode === 16 && index !== 1) {
          getCodeBoxElement(index - 1).focus();
        }
      }
      function onFocusEvent(index) {
        for (item = 1; item < 6; item++) {
          const currentElement = getCodeBoxElement(item);
          if (!currentElement.value) {
              currentElement.focus();
              break;
          } 
        }
      }
    </script>
    </body>
</html>