<?php require_once "controllData.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700&display=swap');
:root{
    --main-color:#6E8EC4;
}
* {
    margin:0; padding:0;
    box-sizing: border-box;
    font-family: 'Roboto', sans-serif;
}
section{
    position: relative;
    width: 95%;
    height: 100vh;
    display:flex;
    padding-left: 5%;
}
section #loginImg{
    position: absolute;
    width: 50%;
    height: 100%;
}
section #loginImg img{
    position: absolute;
    top: 0;
    right: 0;
    left: 100%;
    width: 100%;
    height: 100%;
    object-fit: cover;
}
section #contentImg{
    position: absolute;
    padding-left: 10%;
    width: 100%;
    left: 100%;
    top: 15%;
    font-size: 35px;
    color: #fff;
    object-fit: cover;
}
form {
    position: absolute;
    width: 100%;
}
section #loginHead{
    position: absolute;
    top: 50px;
    font-size: 35px;
}
span{
    font-size: 15px;
    margin-top: 15px;
}
a{
    color:var(--main-color);
    text-decoration: none;
}
#felidPosition{
    display:absolute;
    justify-content:center;
    align-items:center;
    width: 50%;
    height: 100%;
    margin-top:230px;
    
}
.input-field{
  width: 50%;
  padding: 10px 0;
  margin: 5px 0;
  border-left: 0;
  border-top: 0;
  border-right: 0;
  border-bottom: 1px solid #999;
  outline: none;
  background: transparent;
}
.submit-btn{
    width: 50%;
    transition: 0.3s;
    padding: 10px 0;
    cursor: pointer;
    display: block;
    margin: 50px 0;
    background: var(--main-color);
    border: 0;
    outline: none;
    border-radius: 30px;
    color: #fff;
    font-size: 20px;
}
.submit-btn:hover{
    text-decoration: none;
     background-color: #ffffff;
     color: #6E8EC4;
     padding: 8.5px 0;
    border: none;
    outline: 1px solid #010101;
    }
#spanForget{
    padding-left: 32%;
}
    </style>
</head>
<body>
    <section>
        <div id="loginImg">
        <img src="Background.png">
        <div id="contentImg">
               <h2>WELCOME</h3>
                <h4>To the Computer Student<br> 
                Website for Graduation</h4><br>
                <h6>This site allows students to share the idea<br>
                of their graduation projects to be presented<br>
                to the graduation projects committee</h6> 
        </div>
        </div>
        <form action="#" method="POST">
        <div id="loginHead">
        <h2>LOGIN</h2>
        
        <span>Are you new student in KFU? <a href="emailNewP.php" target="_blank"> Create a new account here</a></span>
        </div>

        <div id="felidPosition">
        
        <input type="text" name="userId" class="input-field" 
                    placeholder="Username" required><br>

                    <input type="password" name="password" class="input-field" 
                    placeholder="Password" required><br>
                    <span id="spanForget"><a href="emailforgetP.php" target="_blank">Forget Password?</a></span>
                    <?php 
                        foreach($errors as $error){
                            echo $error;
                                    }
                                ?>
                    <br><button type="submit" name="login" class="submit-btn">LOGIN</button>
           
  </div>
    </section>
    
</body>
</html>